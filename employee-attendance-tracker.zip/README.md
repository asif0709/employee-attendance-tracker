# Employee Attendance Tracker

A Java + MySQL console application for maintaining employee records and daily attendance.

## Features
- Add, update and delete employees
- Mark attendance
- View attendance using a JOIN between employee and attendance tables
- MySQL schema with foreign keys, normalization and an index
- Basic exception handling

## Stack
Java 17 · JDBC · MySQL · SQL · Maven

## Run
1. Install Java 17+, Maven and MySQL.
2. Execute `sql/schema.sql`.
3. Set `DB_URL`, `DB_USER` and `DB_PASSWORD` if required.
4. Run `mvn compile exec:java`.

This is a portfolio implementation created from the project scope described in my resume.
